package com.example.opengl;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import java.util.Random;

import android.content.Context;
import android.opengl.GLSurfaceView.Renderer;
import android.opengl.GLU;

public class MyRenderer implements Renderer{
	


 		private Cubo cubo; 
 	   	private Piramide piramide;
	   
	   
	   private static float anglePyramid = 0; 
	   private static float angleCube = 0;   
	   private static float speedPyramid = 2.0f; 
	   private static float speedCube = -1.5f;    
	   
	   public MyRenderer(Context context) {
	      cubo = new Cubo();
	      piramide = new Piramide();
	   }
	  
	   
	   @Override
	   public void onSurfaceCreated(GL10 gl, EGLConfig config) {
	    
	   }
	   
	   
	   @Override
	   public void onSurfaceChanged(GL10 gl, int width, int height) {
	      
	   }
	  
	
	   @Override
	   public void onDrawFrame(GL10 gl) {
	      gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
	    

	      gl.glLoadIdentity();        
	      gl.glTranslatef(0.0f, 0.0f, 0.0f); 
	      gl.glRotatef(anglePyramid, 0.1f, 1.0f, -0.1f);
	      piramide.dibujar(gl); 
	      

	      gl.glLoadIdentity(); 
	      gl.glTranslatef(0.0f, 0.0f, 0.0f); 
	      gl.glScalef(0.8f, 0.8f, 0.8f); 
	      gl.glRotatef(angleCube, 1.0f, 1.0f, 1.0f); 
	      cubo.dibujar(gl); 
	      
	      angleCube += speedCube;   
	      anglePyramid += speedPyramid;
	     
	   }
	}