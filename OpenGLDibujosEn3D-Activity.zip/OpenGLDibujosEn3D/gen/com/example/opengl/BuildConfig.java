/** Automatically generated file. DO NOT MODIFY */
package com.example.opengl;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}